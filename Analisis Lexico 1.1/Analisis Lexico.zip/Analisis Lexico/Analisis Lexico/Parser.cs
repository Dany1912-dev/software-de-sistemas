﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Analisis_Lexico
{
    internal class Parser
    {
        private List<Token> _tokens;
        private int _posicion;
        private Token _tokenActual;

        public Parser(List<Token> tokens)
        {
            _tokens = tokens;
            _posicion = 0;
            _tokenActual = _tokens[0];
        }

        public void Analizar()
        {
            try
            {
                Programa();
                Console.WriteLine("✅ Análisis sintáctico COMPLETADO sin errores");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ ERROR SINTÁCTICO: {ex.Message}");
            }
        }

        private void Avanzar()
        {
            _posicion++;
            if (_posicion < _tokens.Count)
                _tokenActual = _tokens[_posicion];
            else
                _tokenActual = new Token(TipoToken.EOF, "", 0, 0);
        }

        private void Consumir(TipoToken tipoEsperado)
        {
            if (_tokenActual.Tipo == tipoEsperado)
            {
                Avanzar();
            }
            else
            {
                throw new Exception($"Se esperaba {tipoEsperado} pero se encontró {_tokenActual.Tipo} en línea {_tokenActual.Linea}");
            }
        }

        private bool Coincide(TipoToken tipo)
        {
            return _tokenActual.Tipo == tipo;
        }

        // <programa> ::= <lista_sent>
        private void Programa()
        {
            ListaSentencias();
        }

        // <lista_sent> ::= <sentencia> ';' <lista_sent> | <sentencia_control> <lista_sent> | <sentencia> ';' | <sentencia_control> | ⋋
        private void ListaSentencias()
        {
            while (_tokenActual.Tipo != TipoToken.EOF)
            {
                if (EsInicioSentencia())
                {
                    if (EsSentenciaControl())
                    {
                        SentenciaControl();
                    }
                    else
                    {
                        Sentencia();
                        // Aquí detecta el error de doble punto y coma ;;
                        if (Coincide(TipoToken.PUNTO_Y_COMA))
                        {
                            Consumir(TipoToken.PUNTO_Y_COMA);

                            // ERROR: Doble punto y coma
                            if (Coincide(TipoToken.PUNTO_Y_COMA))
                            {
                                throw new Exception($"Doble punto y coma no permitido en línea {_tokenActual.Linea}");
                            }
                        }
                        else
                        {
                            throw new Exception($"Se esperaba ';' después de sentencia en línea {_tokenActual.Linea}");
                        }
                    }
                }
                else if (Coincide(TipoToken.PUNTO_Y_COMA))
                {
                    // ERROR: Punto y coma al inicio
                    throw new Exception($"Punto y coma sin sentencia previa en línea {_tokenActual.Linea}");
                }
                else
                {
                    throw new Exception($"Sentencia inválida: {_tokenActual.Tipo} en línea {_tokenActual.Linea}");
                }
            }
        }

        // <sentencia_control> ::= <if_simple> | <if_extendido> | <ciclo>
        private void SentenciaControl()
        {
            if (Coincide(TipoToken.IF))
            {
                if (MirarSiguiente() == TipoToken.ELSE)
                {
                    IfExtendido();
                }
                else
                {
                    IfSimple();
                }
            }
            else if (Coincide(TipoToken.WHILE))
            {
                Ciclo();
            }
            else
            {
                throw new Exception($"Sentencia de control inválida: {_tokenActual.Tipo}");
            }
        }

        // <sentencia> ::= (<declaracion> | <asignacion> | <exp_relacional> | <lectura> | <escritura>)
        private void Sentencia()
        {
            if (EsTipo())
            {
                Declaracion();
            }
            else if (Coincide(TipoToken.IDENTIFICADOR))
            {
                Asignacion();
            }
            else if (Coincide(TipoToken.LEER))
            {
                Lectura();
            }
            else if (Coincide(TipoToken.ESCRIBIR))
            {
                Escritura();
            }
            else
            {
                ExpresionRelacional();
            }
        }

        // <declaracion> ::= <tipo> <identificador> | <tipo> <identificador> '=' <factor>
        private void Declaracion()
        {
            // Consumir el tipo (int, char, etc.)
            if (EsTipo())
            {
                Avanzar(); // Consumir el token de tipo
            }
            else
            {
                throw new Exception($"Se esperaba un tipo (int, char, etc.) pero se encontró {_tokenActual.Tipo}");
            }

            Consumir(TipoToken.IDENTIFICADOR);

            if (Coincide(TipoToken.OP_ASIGNACION))
            {
                Consumir(TipoToken.OP_ASIGNACION);
                Factor();
            }
        }

        // <asignacion> ::= <identificador> '=' <factor>
        private void Asignacion()
        {
            Consumir(TipoToken.IDENTIFICADOR);
            Consumir(TipoToken.OP_ASIGNACION);
            Factor();
        }

        // Métodos auxiliares para verificar tipos de tokens
        private bool EsInicioSentencia()
        {
            return EsTipo() ||
                   Coincide(TipoToken.IDENTIFICADOR) ||
                   Coincide(TipoToken.IF) ||
                   Coincide(TipoToken.WHILE) ||
                   Coincide(TipoToken.LEER) ||
                   Coincide(TipoToken.ESCRIBIR) ||
                   EsInicioExpresionRelacional();
        }

        private bool EsSentenciaControl()
        {
            return Coincide(TipoToken.IF) || Coincide(TipoToken.WHILE);
        }

        private bool EsTipo()
        {
            return Coincide(TipoToken.INT) ||
                   Coincide(TipoToken.CHAR) ||
                   Coincide(TipoToken.BOOLEAN) ||
                   Coincide(TipoToken.DOUBLE);
        }

        private bool EsInicioExpresionRelacional()
        {
            return Coincide(TipoToken.IDENTIFICADOR) ||
                   Coincide(TipoToken.LITERAL_ENTERO) ||
                   Coincide(TipoToken.LITERAL_DECIMAL) ||
                   Coincide(TipoToken.PARENTESIS_IZQ);
        }

        // Métodos para expresiones (simplificados)
        private void ExpresionRelacional()
        {
            ExpresionAritmetica();
            if (EsOperadorRelacional())
            {
                Avanzar(); // Operador relacional
                ExpresionAritmetica();
            }
        }

        private void ExpresionAritmetica()
        {
            Termino();
            while (Coincide(TipoToken.OP_SUMA) || Coincide(TipoToken.OP_RESTA))
            {
                Avanzar();
                Termino();
            }
        }

        private void Termino()
        {
            Factor();
            while (Coincide(TipoToken.OP_MULT) || Coincide(TipoToken.OP_DIV))
            {
                Avanzar();
                Factor();
            }
        }

        private void Factor()
        {
            if (Coincide(TipoToken.IDENTIFICADOR) ||
                Coincide(TipoToken.LITERAL_ENTERO) ||
                Coincide(TipoToken.LITERAL_DECIMAL) ||
                Coincide(TipoToken.LITERAL_CADENA) ||
                Coincide(TipoToken.TRUE) ||
                Coincide(TipoToken.FALSE))
            {
                Avanzar();
            }
            else if (Coincide(TipoToken.PARENTESIS_IZQ))
            {
                Consumir(TipoToken.PARENTESIS_IZQ);
                ExpresionAritmetica();
                Consumir(TipoToken.PARENTESIS_DER);
            }
            else
            {
                throw new Exception($"Factor inválido: {_tokenActual.Tipo}");
            }
        }

        private bool EsOperadorRelacional()
        {
            return Coincide(TipoToken.OP_IGUALDAD) ||
                   Coincide(TipoToken.OP_DIFERENTE) ||
                   Coincide(TipoToken.OP_MENOR) ||
                   Coincide(TipoToken.OP_MAYOR) ||
                   Coincide(TipoToken.OP_MENOR_IGUAL) ||
                   Coincide(TipoToken.OP_MAYOR_IGUAL);
        }

        private TipoToken MirarSiguiente()
        {
            if (_posicion + 1 < _tokens.Count)
                return _tokens[_posicion + 1].Tipo;
            return TipoToken.EOF;
        }

        // Implementar los demás métodos: IfSimple, IfExtendido, Ciclo, Lectura, Escritura...
        private void IfSimple() { /* implementar */ }
        private void IfExtendido() { /* implementar */ }
        private void Ciclo() { /* implementar */ }
        private void Lectura() { /* implementar */ }
        private void Escritura() { /* implementar */ }
    }
}
